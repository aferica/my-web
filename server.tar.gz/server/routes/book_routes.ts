/**
 * Created by aferica on 17-6-26.
 */
import * as express from 'express';

import BookController  from '../db_services/book/book_controller';

export default function BookRoutes(app) {

  const router = express.Router();

  const bookController = new BookController();

  // Cats
  router.route('/book/create').get(bookController.create);
  router.route('/book/get').get(bookController.get);

  // Apply the routes to our application with the prefix /api
  app.use('/api', router);

}
