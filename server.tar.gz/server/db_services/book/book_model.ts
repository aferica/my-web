/**
 * Created by aferica on 17-6-26.
 */
import * as mongoose from 'mongoose';

const BookSchema = new mongoose.Schema({
  name: String,
  weight: Number,
  age: Number
});

const Book = mongoose.model('ebook', BookSchema);

export default Book;
