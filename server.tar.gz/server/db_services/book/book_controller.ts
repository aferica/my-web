/**
 * Created by aferica on 17-6-26.
 */
import * as dotenv from 'dotenv';
import * as jwt from 'jsonwebtoken';

import Book from './book_model';

export default class BookController  {
  model = Book;

  create = (req, res) => {
    const obj = new this.model(req.body);
    obj.save((err, item) => {
      // 11000 is the code for duplicate key error
      if (err && err.code === 11000) {
        res.sendStatus(400);
      }
      if (err) {
        return console.error(err);
      }
      res.status(200).json(item);
    });
  }

  get = (req, res) => {
    this.model.find({}, (err, docs) => {
      if (err) { return console.error(err); }
      res.json(docs);
    });
  }

}
